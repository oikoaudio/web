Oiko Inton 0.5.0-beta.1
Source revision: ebdcbe30e32e42cc88a706d8e998f2e21693d36a

Close your DAW before installation. Extract this entire ZIP first.

Copy Oiko Inton.clap to %LOCALAPPDATA%\Programs\Common\CLAP\ and
Oiko Inton.vst3 to %LOCALAPPDATA%\Programs\Common\VST3\.
Keep each bundle intact and add these folders to your DAW's scan paths if needed.
For the MTS runtime, double-click Install MTS-ESP.cmd.
Windows has not yet been manually tested in a DAW.

The runtime installer preserves an existing MTS-ESP installation. If you already
use MTS-ESP Mini or another MTS master, the runtime may already be installed.
The official ODDsound runtime is included unchanged, with its license.
Restart your DAW after installation and rescan plug-ins if necessary.

Inton does not generate sound. Load an MTS-ESP-compatible instrument and select
a scale in Inton. Only one MTS master should be active at a time.

Try scale editing, Set position automation, Morph, and saving/reopening a
project. When reporting issues, include OS, DAW/version, plugin format,
receiving instrument and steps to reproduce.
