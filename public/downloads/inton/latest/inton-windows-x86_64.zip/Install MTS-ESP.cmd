@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-mts.ps1"
set "inton_status=%errorlevel%"
pause
exit /b %inton_status%
