Oiko Inton 0.4.0-beta.1 — public alpha
Source revision: e095a667de83d8d7f904b2f052cc98ae608f8cdd

Close your DAW before installation. Extract this entire ZIP first.

Copy Oiko Inton.clap to ~/.clap/ and Oiko Inton.vst3 to ~/.vst3/.
For the MTS runtime, open a terminal in this extracted folder and run:
  bash scripts/install-mts.sh
The editor uses X11/XWayland, including on a Wayland desktop.

The runtime installer preserves an existing MTS-ESP installation. If you already
use MTS-ESP Mini or another MTS master, the runtime may already be installed.
The official ODDsound runtime is included unchanged, with its license.
Restart your DAW after installation and rescan plug-ins if necessary.

Inton does not generate sound. Load an MTS-ESP-compatible instrument and select
a scale in Inton. Only one MTS master should be active at a time.

Try scale editing, Set position automation, Morph, and saving/reopening a
project. When reporting issues, include OS, DAW/version, plugin format,
receiving instrument and steps to reproduce.
