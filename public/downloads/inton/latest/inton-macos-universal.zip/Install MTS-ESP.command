#!/bin/bash
cd "$(dirname "$0")"
bash scripts/install-mts.sh
status=$?
read -r -p "Press Return to close."
exit "$status"
