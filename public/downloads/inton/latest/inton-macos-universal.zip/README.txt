Oiko Inton 0.3.80 — public alpha
Source revision: fad67b4b476d21ca0a0ea512dadd307d99856910

Close your DAW before installation. Extract this entire ZIP first.

Copy Oiko Inton.clap to ~/Library/Audio/Plug-Ins/CLAP/ and
Oiko Inton.vst3 to ~/Library/Audio/Plug-Ins/VST3/. Keep each bundle intact.
For the MTS runtime, double-click Install MTS-ESP.command.
This universal build supports Apple Silicon and Intel Macs.

The runtime installer preserves an existing MTS-ESP installation. If you already
use MTS-ESP Mini or another MTS master, the runtime may already be installed.
The official ODDsound runtime is included unchanged, with its license.
Restart your DAW after installation and rescan plug-ins if necessary.

Inton does not generate sound. Load an MTS-ESP-compatible instrument and select
a scale in Inton. Only one MTS master should be active at a time.

Try scale editing, Set position automation, Morph, and saving/reopening a
project. When reporting issues, include OS, DAW/version, plugin format,
receiving instrument and steps to reproduce.
